import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore';
import { Employee, BranchItem, SettingsConfig, AuditLog } from '../types';
import { INITIAL_AREAS, INITIAL_BRANCHES, INITIAL_DESIGNATIONS, INITIAL_SETTINGS, INITIAL_EMPLOYEES } from '../data/initialData';
import { db, isFirebaseConfigured, authReady } from './firebase';

// ডিভাইস-নির্ভর (localStorage) সেটিংস — এগুলো প্রতিটি কম্পিউটারে আলাদা থাকে
const LOCAL_KEYS = {
  THEME: 'sss_ctg02_theme_v1',
  LANGUAGE: 'sss_ctg02_lang_v1',
};

// Firebase কনফিগার করা না থাকলে ব্যবহৃত হয় (একই কম্পিউটারে সংরক্ষণ, আগের আচরণ)
const OFFLINE_CACHE_KEY = 'sss_ctg02_offline_cache_v1';

function offlineSave(): void {
  try {
    localStorage.setItem(
      OFFLINE_CACHE_KEY,
      btoa(
        encodeURIComponent(
          JSON.stringify({
            employees: cache.employees,
            areas: cache.areas,
            branches: cache.branches,
            designations: cache.designations,
            settings: cache.settings,
            auditLogs: cache.auditLogs,
          })
        )
      )
    );
  } catch (err) {
    console.error('Offline save failed:', err);
  }
}

function offlineLoad(): void {
  try {
    const raw = localStorage.getItem(OFFLINE_CACHE_KEY);
    if (!raw) return;
    const parsed = JSON.parse(decodeURIComponent(atob(raw)));
    cache = { ...cache, ...parsed };
  } catch (err) {
    console.error('Offline load failed:', err);
  }
}

// শেয়ার করা (Firestore) ডেটার ক্যাশ — সব কম্পিউটারে একই থাকে
interface SharedCache {
  employees: Employee[];
  areas: string[];
  branches: BranchItem[];
  designations: string[];
  settings: SettingsConfig;
  auditLogs: AuditLog[];
}

let cache: SharedCache = {
  employees: INITIAL_EMPLOYEES,
  areas: INITIAL_AREAS,
  branches: INITIAL_BRANCHES,
  designations: INITIAL_DESIGNATIONS,
  settings: INITIAL_SETTINGS,
  auditLogs: [],
};

let hasSynced = false;
type Listener = () => void;
let listeners: Listener[] = [];

function notify() {
  listeners.forEach((l) => l());
}

// কম্পোনেন্ট থেকে ডেটা বদলের খবর পেতে এটা ব্যবহার হয় (App.tsx-এ)
export function onStorageChange(cb: Listener): () => void {
  listeners.push(cb);
  return () => {
    listeners = listeners.filter((l) => l !== cb);
  };
}

export function isCloudConnected(): boolean {
  return isFirebaseConfigured;
}

export function hasSyncedOnce(): boolean {
  return hasSynced;
}

const DB_DOC = () => doc(db, 'sss_ctg02_zone', 'database');
const LOGS_DOC = () => doc(db, 'sss_ctg02_zone', 'auditLogs');

if (isFirebaseConfigured) {
  authReady.then(() => {
    onSnapshot(
      DB_DOC(),
      (snap) => {
        if (snap.exists()) {
          const data = snap.data() as Partial<SharedCache>;
          cache = {
            ...cache,
            employees: data.employees ?? cache.employees,
            areas: data.areas ?? cache.areas,
            branches: data.branches ?? cache.branches,
            designations: data.designations ?? cache.designations,
            settings: data.settings ?? cache.settings,
          };
        } else {
          // প্রথমবার: শুরুর ডেমো ডেটা ক্লাউডে লিখে দিচ্ছে
          setDoc(DB_DOC(), {
            employees: cache.employees,
            areas: cache.areas,
            branches: cache.branches,
            designations: cache.designations,
            settings: cache.settings,
          }).catch((err) => console.error('Initial seed failed:', err));
        }
        hasSynced = true;
        notify();
      },
      (err) => {
        console.error('Firestore sync error (database):', err);
        hasSynced = true;
        notify();
      }
    );

    onSnapshot(
      LOGS_DOC(),
      (snap) => {
        cache.auditLogs = snap.exists() ? (snap.data().logs as AuditLog[]) ?? [] : [];
        notify();
      },
      (err) => console.error('Firestore sync error (logs):', err)
    );
  });
} else {
  // Firebase কনফিগার করা না থাকলে পুরনো আচরণ (এই কম্পিউটারেই সংরক্ষণ) বজায় থাকে
  offlineLoad();
  hasSynced = true;
}

export const StorageService = {
  getEmployees(): Employee[] {
    return cache.employees;
  },
  saveEmployees(employees: Employee[]): void {
    cache.employees = employees;
    if (isFirebaseConfigured) {
      setDoc(DB_DOC(), { employees }, { merge: true }).catch((err) => console.error('Save employees failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  getAreas(): string[] {
    return cache.areas;
  },
  saveAreas(areas: string[]): void {
    cache.areas = areas;
    if (isFirebaseConfigured) {
      setDoc(DB_DOC(), { areas }, { merge: true }).catch((err) => console.error('Save areas failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  getBranches(): BranchItem[] {
    return cache.branches;
  },
  saveBranches(branches: BranchItem[]): void {
    cache.branches = branches;
    if (isFirebaseConfigured) {
      setDoc(DB_DOC(), { branches }, { merge: true }).catch((err) => console.error('Save branches failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  getDesignations(): string[] {
    return cache.designations;
  },
  saveDesignations(designations: string[]): void {
    cache.designations = designations;
    if (isFirebaseConfigured) {
      setDoc(DB_DOC(), { designations }, { merge: true }).catch((err) => console.error('Save designations failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  getSettings(): SettingsConfig {
    return cache.settings;
  },
  saveSettings(settings: SettingsConfig): void {
    cache.settings = settings;
    if (isFirebaseConfigured) {
      setDoc(DB_DOC(), { settings }, { merge: true }).catch((err) => console.error('Save settings failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  getAuditLogs(): AuditLog[] {
    return cache.auditLogs;
  },
  addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): void {
    const newEntry: AuditLog = {
      ...log,
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString(),
    };
    const trimmed = [newEntry, ...cache.auditLogs].slice(0, 200);
    cache.auditLogs = trimmed;
    if (isFirebaseConfigured) {
      setDoc(LOGS_DOC(), { logs: trimmed }, { merge: true }).catch((err) => console.error('Save audit log failed:', err));
    } else {
      offlineSave();
    }
    notify();
  },

  // ডিভাইস-নির্ভর সেটিংস (থিম/ভাষা) — এগুলো সবসময় localStorage-এ থাকে
  getTheme(): 'light' | 'dark' {
    return (localStorage.getItem(LOCAL_KEYS.THEME) as 'light' | 'dark') || 'light';
  },
  saveTheme(theme: 'light' | 'dark'): void {
    localStorage.setItem(LOCAL_KEYS.THEME, theme);
  },

  getLanguage(): 'bn' | 'en' {
    return (localStorage.getItem(LOCAL_KEYS.LANGUAGE) as 'bn' | 'en') || 'bn';
  },
  saveLanguage(lang: 'bn' | 'en'): void {
    localStorage.setItem(LOCAL_KEYS.LANGUAGE, lang);
  },

  // সম্পূর্ণ ব্যাকআপ (JSON ফাইল ডাউনলোড করার জন্য)
  createFullBackupJson(): string {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      organization: 'SSS Chattogram-02',
      employees: cache.employees,
      areas: cache.areas,
      branches: cache.branches,
      designations: cache.designations,
      settings: cache.settings,
      auditLogs: cache.auditLogs,
    };
    return JSON.stringify(backup, null, 2);
  },

  // ব্যাকআপ থেকে ফিরিয়ে আনা (ক্লাউডে থাকলে সবার কাছে পৌঁছে যাবে)
  restoreBackupJson(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (Array.isArray(data.employees)) this.saveEmployees(data.employees);
      if (Array.isArray(data.areas)) this.saveAreas(data.areas);
      if (Array.isArray(data.branches)) this.saveBranches(data.branches);
      if (Array.isArray(data.designations)) this.saveDesignations(data.designations);
      if (data.settings && typeof data.settings === 'object') {
        this.saveSettings({ ...INITIAL_SETTINGS, ...data.settings });
      }
      this.addAuditLog({
        action: 'RESTORE',
        performedBy: 'Admin',
        details: `Restored database backup containing ${data.employees?.length || 0} employees`,
      });
      return true;
    } catch (err) {
      console.error('Restore failed:', err);
      return false;
    }
  },

  resetToDefaults(): void {
    this.saveEmployees(INITIAL_EMPLOYEES);
    this.saveAreas(INITIAL_AREAS);
    this.saveBranches(INITIAL_BRANCHES);
    this.saveDesignations(INITIAL_DESIGNATIONS);
    this.saveSettings(INITIAL_SETTINGS);
    this.addAuditLog({
      action: 'UPDATE',
      performedBy: 'Admin',
      details: 'Reset system to default Chattogram-02 zone database',
    });
  },
};

// শুরুতে একবার সিঙ্ক করতে সাহায্য করার জন্য (ঐচ্ছিক ব্যবহার)
export async function waitForInitialSync(): Promise<void> {
  if (!isFirebaseConfigured) return;
  await authReady;
  await getDoc(DB_DOC()).catch(() => undefined);
}
