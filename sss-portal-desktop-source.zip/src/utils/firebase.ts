import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, signInAnonymously, onAuthStateChanged } from 'firebase/auth';

// ============================================================
// এখানে আপনার নিজের Firebase প্রজেক্টের তথ্য বসান।
// Firebase Console → Project settings → General → Your apps → SDK setup
// থেকে এই মানগুলো কপি করে নিচে বসিয়ে দিন।
// ============================================================
const firebaseConfig = {
  apiKey: 'PASTE_YOUR_API_KEY_HERE',
  authDomain: 'PASTE_YOUR_PROJECT_ID.firebaseapp.com',
  projectId: 'PASTE_YOUR_PROJECT_ID',
  storageBucket: 'PASTE_YOUR_PROJECT_ID.appspot.com',
  messagingSenderId: 'PASTE_YOUR_SENDER_ID',
  appId: 'PASTE_YOUR_APP_ID',
};

export const isFirebaseConfigured = firebaseConfig.apiKey !== 'PASTE_YOUR_API_KEY_HERE';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

let authReadyResolve: () => void;
export const authReady: Promise<void> = new Promise((resolve) => {
  authReadyResolve = resolve;
});

if (isFirebaseConfigured) {
  onAuthStateChanged(auth, (user) => {
    if (!user) {
      signInAnonymously(auth).catch((err) => console.error('Anonymous sign-in failed:', err));
    } else {
      authReadyResolve();
    }
  });
} else {
  // Firebase কনফিগার করা না থাকলে অ্যাপ যেন আটকে না থাকে
  authReadyResolve!();
}
